import { SubstrPipe } from './substr.pipe';

describe('SubstrPipe', () => {
  it('create an instance', () => {
    const pipe = new SubstrPipe();
    expect(pipe).toBeTruthy();
  });
});
