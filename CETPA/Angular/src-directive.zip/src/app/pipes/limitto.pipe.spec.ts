import { LimittoPipe } from './limitto.pipe';

describe('LimittoPipe', () => {
  it('create an instance', () => {
    const pipe = new LimittoPipe();
    expect(pipe).toBeTruthy();
  });
});
